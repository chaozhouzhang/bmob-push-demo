package cn.bmob.pushsdk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.orhanobut.logger.Logger;

/**
 * Created on 17/9/7 13:31
 * @author zhangchaozhou
 */

public class PushReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String msg = intent.getStringExtra("msg");
        Logger.i(msg);
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }
}
