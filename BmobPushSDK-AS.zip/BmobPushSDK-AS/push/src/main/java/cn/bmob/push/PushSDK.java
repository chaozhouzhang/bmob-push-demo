package cn.bmob.push;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;

import java.util.List;
import java.util.Observable;
import java.util.Observer;

import cn.bmob.push.lib.service.ISocketService;
import cn.bmob.push.lib.service.ISocketServiceCallback;
import cn.bmob.push.lib.service.PushService;
import cn.bmob.push.lib.util.BLog;

/**
 * PushSDK 包装类，各个应用只要调用该类的相关方法，不需要调用其它类的方法
 *
 * @author zhangchaozhou
 */
public class PushSDK {

    private ISocketService mService = null;
    private PushObservable mPushObservable = new PushObservable();
    private Context mContext = null;
    /**
     * 创建private static类实例
     */

    private volatile static PushSDK INSTANCE;
    /**
     * 同步锁
     */
    private static Object INSTANCE_LOCK = new Object();


    public static PushSDK getInstance() {
        return INSTANCE;
    }

    /**
     * 使用单例模式创建--多线程访问中运用双重锁定
     */
    public static PushSDK getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (INSTANCE_LOCK) {
                if (INSTANCE == null) {
                    INSTANCE = new PushSDK();
                }
                INSTANCE.init(context);
            }
        }
        return INSTANCE;
    }

    private void init(Context context) {
        this.mContext = context.getApplicationContext();
    }

    /**
     * 注册应用，注册后可以收到推送消息
     */

    public boolean startService() {
        try {
            Intent mIntent = new Intent();
            mIntent.setAction(PushService.class.getName());
            /**
             *  隐式启动Service在android 5.0的时候会出现如下两类错误
             *  IllegalArgumentException: Service Intent must be explicit
             *  或者Implicit intents with startService are not safe
             */
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
                BLog.e(mContext.getPackageName());
                mIntent.setPackage(mContext.getPackageName());
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    mContext.startForegroundService(mIntent);
                } else {
                    mContext.startService(mIntent);
                }
                return mContext.bindService(mIntent, conn,
                        Context.BIND_AUTO_CREATE);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                mContext.startForegroundService(mIntent);
            } else {
                mContext.startService(mIntent);
            }
            return mContext
                    .bindService(mIntent, conn, Context.BIND_AUTO_CREATE);
        } catch (Exception e) {
            BLog.e(e.getMessage());
            return false;
        }
    }

    /**
     * 注销应用，注销后无法收到推送消息
     */
    public void stopService() {
        try {
            if (null != mService) {
                Intent mIntent = new Intent(PushService.class.getName());
                // 如果调用了startService那么必须调用stopService
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
                    mIntent.setPackage(mContext.getPackageName());
                }
                mContext.stopService(mIntent);
                mService.unregisterCallback(null, mCallBack);
                mContext.unbindService(conn);
                mService = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 客户端的调用
     */
    private ServiceConnection conn = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
            BLog.d("PushSDK", "onServiceDisconnected");
            try {
                mService.unregisterCallback(null, mCallBack);
            } catch (RemoteException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            mService = null;
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            BLog.d("PushSDK", "onServiceConnected");
            // 得到远程的Binder
            mService = ISocketService.Stub.asInterface(service);
            try {
                // 注册回调 使得他的观察者比如PushService能收到消息data
                mService.registerCallback(null, mCallBack);
            } catch (RemoteException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    private ISocketServiceCallback mCallBack = new ISocketServiceCallback.Stub() {

        @Override
        public void response(Bundle mBundle) throws RemoteException {
            try {
                byte[] data = mBundle.getByteArray("data");
                if (null != mPushObservable) {
                    mPushObservable.notifyPush(new String(data));
                }
            } catch (Exception e) {
                e.printStackTrace();
                startService();
            }
        }
    };

    /**
     * 注册网络回调
     *
     * @param observer 观察者对象
     */
    public void registerPushListener(Observer observer) {
        if (observer == null) {
            return;
        }
        mPushObservable.addObserver(observer);
    }

    /**
     * 解注册网络回调
     *
     * @param observer 先前注册过的观察者对象
     */
    public void unRegisterPushListener(Observer observer) {
        if (observer == null) {
            return;
        }
        mPushObservable.deleteObserver(observer);
    }

    private class PushObservable extends Observable {

        public void notifyPush(Object message) {
            setChanged();
            notifyObservers(message);
        }
    }

    public static Intent getExplicitIntent(Context context,
                                           Intent implicitIntent) {
        // Retrieve all services that can match the given intent
        PackageManager pm = context.getPackageManager();
        List<ResolveInfo> resolveInfo = pm.queryIntentServices(implicitIntent,
                0);
        // Make sure only one match was found
        if (resolveInfo == null || resolveInfo.size() != 1) {
            return null;
        }
        // Get component info and create ComponentName
        ResolveInfo serviceInfo = resolveInfo.get(0);
        String packageName = serviceInfo.serviceInfo.packageName;
        // String packageName = "cn.bmob.push.lib.service";
        String className = serviceInfo.serviceInfo.name;
        ComponentName component = new ComponentName(packageName, className);
        // Create a new intent. Use the old one for extras and such reuse
        Intent explicitIntent = new Intent(implicitIntent);
        // Set the component to be explicit
        explicitIntent.setComponent(component);
        return explicitIntent;
    }

}
