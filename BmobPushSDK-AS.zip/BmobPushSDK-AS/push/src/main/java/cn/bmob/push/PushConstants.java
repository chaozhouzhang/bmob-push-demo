package cn.bmob.push;

public class PushConstants {
	/**
	 * 接收推送消息的action
	 */
	public static String ACTION_MESSAGE = "cn.bmob.push.action.MESSAGE";
	/**
	 * 接收心跳广播的action
	 */
	public static String ACTION_HEARTBEAT = "cn.bmob.push.action.HEARTBEAT";
	/**
	 * 接收唤醒广播的action
	 */
	public static String ACTION_NOTIFY = "cn.bmob.push.action.NOTIFY";
	/**
	 * 接收消息的extra
	 */
	public static String EXTRA_PUSH_MESSAGE_STRING = "msg";
}
