package cn.bmob.push;

import android.content.Context;
import cn.bmob.push.lib.service.Client;
import cn.bmob.push.lib.service.Client.VolleyListener;

public class BmobPush {
	/**
	 * 当前SDK版本号
	 */
	public static final String VERSION="0.9";
	
	/**
	 * 调试模式
	 */
	public static boolean DEBUG_MODE = false;
	
	/** 设置调试模式
	  * @param  
	  * @return void
	  */
	public static void setDebugMode(boolean isDebug){
		DEBUG_MODE = isDebug;
	}
	
	/** 启动推送服务
	  * @param  context
	  * @return void
	  */
	public static void startWork(final Context context){
		Client client = new Client(context);
		client.getServer(new VolleyListener() {
			
			@Override
			public void onSuccess(String server) {
				PushSDK.getInstance(context).startService();
			}
		});
	}
	
	/**停止push服务  
	 * @method stopWork    
	 * @return void  
	 */
	public static void stopWork(){
		PushSDK sdk =PushSDK.getInstance();
		if(sdk!=null){
			sdk.stopService();
		}
	}
}
