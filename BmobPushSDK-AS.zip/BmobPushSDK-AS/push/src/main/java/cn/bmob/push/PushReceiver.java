package cn.bmob.push;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import cn.bmob.push.lib.service.PushService;
import cn.bmob.push.lib.util.WakefulBroadcastReceiver;

public class PushReceiver extends WakefulBroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		String action = intent.getAction();
		if (!PushService.isUnReceive()) {
			if("android.intent.action.USER_PRESENT".equals(action)){//监听解锁广播
				PushSDK.getInstance(context).startService();
			}else if ("android.net.conn.CONNECTIVITY_CHANGE".equals(action)) {//监听网络状态变化广播  
				ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
				NetworkInfo networkInfo = cm.getActiveNetworkInfo();
				if (networkInfo != null && networkInfo.isAvailable()) {//网络可用，则重启service
					PushSDK.getInstance(context).startService();
				}else{
					PushSDK.getInstance(context).stopService();
				}
			} else if("android.intent.action.BOOT_COMPLETED".equals(action)){//开机启动
				PushSDK.getInstance(context).startService();
			}
		}
	}
}
