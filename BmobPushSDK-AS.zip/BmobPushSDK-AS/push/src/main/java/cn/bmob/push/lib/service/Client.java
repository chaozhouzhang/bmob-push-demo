package cn.bmob.push.lib.service;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.concurrent.LinkedBlockingQueue;

import cn.bmob.push.BmobPush;
import cn.bmob.push.PushConstants;
import cn.bmob.push.PushNotifyReceiver;
import cn.bmob.push.autobahn.WebSocketConnection;
import cn.bmob.push.autobahn.WebSocketConnectionHandler;
import cn.bmob.push.config.Constant;
import cn.bmob.push.lib.util.AtomicIntegerUtil;
import cn.bmob.push.lib.util.BLog;
import cn.bmob.push.lib.util.BmobPreferenceUtil;
import cn.volley.Request;
import cn.volley.Response;
import cn.volley.VolleyError;
import cn.volley.toolbox.JsonObjectRequest;
import cn.volley.toolbox.Volley;

/**
 * 客户端包装类
 * 
 * @author Administrator
 * 
 */
public class Client {

	private static WebSocketConnection socket;
	private Context context;
	private ISocketResponse mSocketResponseListener;
	private LinkedBlockingQueue<ClientPacket> requestQueen = new LinkedBlockingQueue<ClientPacket>();
	private final String TAG = "BmobClient";
	private AlarmManager mAlarmManager;
	private PendingIntent mPendingIntent;
	// 创建private static类实例
	private volatile static Client INSTANCE;
	// 同步锁
	private static Object INSTANCE_LOCK = new Object();
	
	public static Client getInstance() {
		return INSTANCE;
	}

	/**
	 * 使用单例模式创建--多线程访问中运用双重锁定
	 */
	public static Client getInstance(Context context) {
		if (INSTANCE == null)
			synchronized (INSTANCE_LOCK) {
				if (INSTANCE == null) {
					INSTANCE = new Client(context);
				}
			}
		return INSTANCE;
	}

	public Client(Context context) {
		this.context = context.getApplicationContext();
		socket = new WebSocketConnection();
	}

	public void initHeartBeat() {
		// 获取闹钟服务对象
		mAlarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
		Intent intent = new Intent(context, PushNotifyReceiver.class);
		intent.setAction(PushConstants.ACTION_HEARTBEAT);
		context.sendBroadcast(intent);
		mPendingIntent = PendingIntent.getBroadcast(context, 0, intent, 0);
		// 当前时间每隔60秒执行一次
		mAlarmManager.setRepeating(AlarmManager.RTC_WAKEUP,System.currentTimeMillis(), 60 * 1000, mPendingIntent);
	}
	
	
	public void cancleHeartBeat(){
		mAlarmManager.cancel(mPendingIntent);
	}

	public int send(ClientPacket in) {
		socket.sendTextMessage(new String(in.getData()));
		return 0;
	}

	public void cancel(int reqId) {
		Iterator<ClientPacket> mIterator = requestQueen.iterator();
		while (mIterator.hasNext()) {
			ClientPacket packet = mIterator.next();
			if (packet.getPackId() == reqId) {
				mIterator.remove();
			}
		}
	}

	private long lastConnTime = 0;

	/**
	 * 连接socket
	 * @param mSocketResponseListener
	 * @return void
	 */
	public synchronized void open(ISocketResponse mSocketResponseListener) {
		this.mSocketResponseListener = mSocketResponseListener;
		if (System.currentTimeMillis() - lastConnTime < 2000) {
			return;
		}
		lastConnTime = System.currentTimeMillis();
		// 获取本地的服务器地址,因为有可能上一次连接失败会清空本地缓存，所以此时做下判断
		String serverUrl = new BmobPreferenceUtil(context).getServer();
		if (TextUtils.isEmpty(serverUrl)) {
			getServer(new VolleyListener() {

				@Override
				public void onSuccess(String server) {
					conn(server);
				}
			});
		} else {
			conn(serverUrl);
		}
	}

	/**
	 * 关闭socket连接
	 * 
	 * @method close
	 * @return void
	 */
	public synchronized void close() {
		if (socket != null && isSocketConnected()) {
			socket.disconnect();
		}
	}

	public synchronized boolean isSocketConnected() {
		return socket.isConnected();
	}

	public interface VolleyListener {
		/**
		 * 获取服务器地址
		 * @param server
		 */
		void onSuccess(String server);
	}

	/**
	 * 从服务器获取地址
	 * 
	 * @param listener
	 */
	public void getServer(final VolleyListener listener) {
		// 组装完整的请求路径
		String allUrl = Constant.initUrl + "/server/get?key="+ AtomicIntegerUtil.getInstallationId(context) + "&proto=1";
		Volley.newRequestQueue(context).add(new JsonObjectRequest(Request.Method.GET, allUrl, null,new Response.Listener<JSONObject>() {

				@Override
				public void onResponse(JSONObject response) {
					try {
						int ret = response.optInt("ret");
						if (ret == 0) {
							String server = response.optJSONObject("data").optString("server", "");
							new BmobPreferenceUtil(context).saveServer(server);
							listener.onSuccess(server);
						} else {
							String msg = response.optString("msg");
							Log.e("bmob", "error code:" + ret+ ",error msg:" + msg);
							new BmobPreferenceUtil(context).removeServer();
						}
					} catch (Throwable e) {
						new BmobPreferenceUtil(context).removeServer();
					}
				}
			}, new Response.ErrorListener() {

				@Override
				public void onErrorResponse(VolleyError error) {
					// 初始化失败就应该删除本地保存的服务器地址
					new BmobPreferenceUtil(context).removeServer();
				}
			}));
	}

	private void conn(String serverUrl) {
		// 获得设备唯一标示
		String key = AtomicIntegerUtil.getInstallationId(context);
		String wsUri = "ws://" + serverUrl + "/sub?key=" + key+ "&cmd=sub&version=" + BmobPush.VERSION + "&heartbeat="+ Constant.HEARTBEAT_TIME;
		try {
			socket.connect(wsUri, new WebSocketConnectionHandler() {
				@Override
				public void onOpen() {
					initHeartBeat();
				}

				@Override
				public void onClose(int code, String reason) {
					// 连接中断有几种情况：网络切换、服务器地址无法连接、连接超时、服务器重启造成的连接主动断开等情况
					// 客户端会重启service服务，在重启完成后刚开始几条消息会接收的比较慢
					BLog.i(TAG+"连接中断:" + code + "--" + reason);
					// 如果是开发者关闭就不要重连 TODO 这里可能还有进程访问变量问题
					if (!PushService.isUnReceive()) {
						// 重新请求服务器
						retryConnect();
					}
				}

				@Override
				public void onTextMessage(String payload) {
					super.onTextMessage(payload);
					BLog.e("收到payload is" + payload);
					// 发送文本
					if (null != mSocketResponseListener) {
						mSocketResponseListener.onSocketResponse(1,
								payload.getBytes());
					}
				}
			});
		} catch (Exception e) {
			BLog.d(TAG, "WebSocketException = " + e.getMessage());
			if (!e.getMessage().equals("already connected")) {// 只要不是already connected，则需要重新请求服务器地址
				retryConnect();
			}
		}
	}

	/**
	 * 发心跳
	 */
	@SuppressLint("SimpleDateFormat")
	public void sendHeartBeat() {
			if (socket.isConnected()) {
				Date date = new Date(System.currentTimeMillis());
				SimpleDateFormat format = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
				BLog.i("--->+h-->" + format.format(date));
				socket.sendTextMessage("h");
				BLog.i("通过AM发的心跳");
			} else {
				// 因为是静态注册 所以可能socket还没连接上
				conn(new BmobPreferenceUtil(context).getServer());
			}

	}

	/**
	 * 重新请求服务器地址
	 */
	public void retryConnect() {
		// 关闭原有连接
		close();
		// 清空本地存储的server地址
		new BmobPreferenceUtil(context).removeServer();
		// 重新启动推送服务
		BmobPush.startWork(context);
	}

}
