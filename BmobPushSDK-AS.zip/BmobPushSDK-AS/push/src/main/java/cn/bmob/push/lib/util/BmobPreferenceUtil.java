package cn.bmob.push.lib.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class BmobPreferenceUtil {

	public static String NAME_SPNAME = "bmob_push";
	public static String KEY_SERVERURL = "server_url";

	private SharedPreferences sp = null;
	private Editor edit = null;

	/**
	 * Create DefaultSharedPreferences
	 * 
	 * @param context
	 */
	public BmobPreferenceUtil(Context context) {
		this(context.getApplicationContext()
				.getSharedPreferences(NAME_SPNAME, Context.MODE_PRIVATE));
	}

	/**
	 * Create SharedPreferences by SharedPreferences
	 * 
	 * @param context
	 * @param sp
	 */
	public BmobPreferenceUtil(SharedPreferences sp) {
		this.sp = sp;
		edit = sp.edit();
	}

	// Set
	// String
	private void setValue(String key, String value) {
		edit.putString(key, value);
		edit.commit();
	}

	// String
	private String getValue(String key, String defaultValue) {
		return sp.getString(key, defaultValue);
	}

	/**
	 * @param server
	 */
	public void saveServer(String server) {
		setValue(KEY_SERVERURL, server);
	}

	/**
	 * 获取本地存储的server地址
	 * 
	 * @return
	 */
	public String getServer() {
		return getValue(KEY_SERVERURL, "");
	}

	/**
	 * 删除本地存储的地址
	 */
	public void removeServer() {
		remove(KEY_SERVERURL);
	}

	// Delete
	private void remove(String key) {
		edit.remove(key);
		edit.commit();
	}

	public void clear() {
		edit.clear();
		edit.commit();
	}

}
