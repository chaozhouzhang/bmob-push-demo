package cn.bmob.push;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import cn.bmob.push.lib.service.Client;
import cn.bmob.push.lib.service.PushService;
import cn.bmob.push.lib.util.BLog;

/**
 * 接收AlarmManager周期发的广播
 */
public class PushNotifyReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		if(intent==null){
			return;
		}
		// 发心跳
		if (PushConstants.ACTION_HEARTBEAT.equals(intent.getAction())) {
			BLog.i("receive ACTION_HEARTBEAT");
			BLog.i("PushService.isUnReceive()--->"+ PushService.isUnReceive());
			if (!PushService.isUnReceive()) {
				Client.getInstance(context).sendHeartBeat();
			}
			// 保持PushService的运行
		} else if (PushConstants.ACTION_NOTIFY.equals(intent.getAction())) {
			BLog.i("receive ACTION_NOTIFY");
			if (!PushService.isUnReceive()) {
				boolean isServiceRunning = false;
				// 检查Service状态
				ActivityManager manager = (ActivityManager) context.getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);
				for (RunningServiceInfo service : manager
						.getRunningServices(Integer.MAX_VALUE)) {
					if (PushService.class.getName().equals(
							service.service.getClassName())) {
						isServiceRunning = true;
					}
				}
				if (!isServiceRunning) {
					BLog.i("PushService服务未启动或已关闭,正在启动中...");
					PushSDK.getInstance(context.getApplicationContext()).startService();
				} else {
					BLog.i(context.getPackageName() + "-->"+ "PushService服务正在运行中");
				}
			}
		}
	}

}
