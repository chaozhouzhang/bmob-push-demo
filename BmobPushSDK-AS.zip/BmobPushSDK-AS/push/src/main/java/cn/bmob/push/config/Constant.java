package cn.bmob.push.config;

/**
 * 常量
 */
public class Constant {
	
	/**
	 * 外网地址
	 */
	public static String initUrl = "http://push.bmob.cn";
//	/**
//	 * 内网地址
//	 */
//	private static String initUrl = "192.168.1.60:6968";
	
	/**
	 * 心跳时间(秒)
	 */
	public static int HEARTBEAT_TIME = 120;
	
	/**
	 * 隔60s再发一次心跳包
	 */
	public static long HEART_HALF_TIME = 60*1000;
	
}
