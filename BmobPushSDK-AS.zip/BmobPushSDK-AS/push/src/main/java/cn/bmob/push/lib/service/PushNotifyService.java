package cn.bmob.push.lib.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

/**
 * 唤醒service
 */
public class PushNotifyService extends Service {
    private final static int IM_SERVICE_ID = 1001;

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground();
        stopForeground(true);
        stopSelf();
        return super.onStartCommand(intent, flags, startId);
    }


    private void startForeground() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            String id = "ID";
            String name = "NAME";
            NotificationChannel channel = new NotificationChannel(id, name, NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
            Notification notification = new Notification.Builder(this, id).build();
            startForeground(IM_SERVICE_ID, notification);
        } else {
            startForeground(IM_SERVICE_ID, new Notification());
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

}
