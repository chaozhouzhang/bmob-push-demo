//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package cn.bmob.push.lib.util;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;
import android.util.SparseArray;

public abstract class WakefulBroadcastReceiver extends BroadcastReceiver {
    private static final SparseArray<WakeLock> mActiveWakeLocks = new SparseArray<WakeLock>();
    private static int mNextId = 1;

    public WakefulBroadcastReceiver() {
    }

    public static ComponentName startWakefulService(Context context, Intent intent) {
        synchronized (mActiveWakeLocks) {
            int id = mNextId++;
            if (mNextId <= 0) {
                mNextId = 1;
            }

            intent.putExtra("android.support.content.wakelockid", id);
            ComponentName comp;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                comp = context.startForegroundService(intent);
            } else {
                comp = context.startService(intent);
            }

            if (comp == null) {
                return null;
            } else {
                PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                WakeLock wl = pm.newWakeLock(1, "wake:" + comp.flattenToShortString());
                wl.setReferenceCounted(false);
                wl.acquire(60000L);
                mActiveWakeLocks.put(id, wl);
                return comp;
            }
        }
    }

    public static boolean completeWakefulIntent(Intent intent) {
        int id = intent.getIntExtra("android.support.content.wakelockid", 0);
        if (id == 0) {
            return false;
        } else {
            synchronized (mActiveWakeLocks) {
                WakeLock wl = (WakeLock) mActiveWakeLocks.get(id);
                if (wl != null) {
                    wl.release();
                    mActiveWakeLocks.remove(id);
                    return true;
                } else {
                    Log.w("WakefulReceiver", "No active wake lock id #" + id);
                    return true;
                }
            }
        }
    }
}
