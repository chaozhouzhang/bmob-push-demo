package cn.bmob.push.lib.service;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteCallbackList;
import android.os.RemoteException;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Observable;
import java.util.Observer;

import cn.bmob.push.PushConstants;
import cn.bmob.push.PushNotifyReceiver;
import cn.bmob.push.PushSDK;
import cn.bmob.push.lib.util.BLog;
import cn.bmob.push.lib.util.NetworkUtil;

/**
 * 后台服务类
 */
public class PushService extends Service {

	private Client mClient = null;
	/**
	 * 开发者关闭推送开关
	 */
	private static boolean isUnReceive = false;
	private AlarmManager mAlarmManager;
	private PendingIntent mPendingIntent;

	public static boolean isUnReceive() {
		return isUnReceive;
	}

	public static void setUnReceive(boolean isUnReceive) {
		PushService.isUnReceive = isUnReceive;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		BLog.d("PushService", "PushService-->onCreate()");
		mClient = new Client(getApplicationContext());
		// 启动及绑定Service并开启回调监听
		if (!isUnReceive) {
			PushSDK.getInstance(getApplicationContext()).startService();
			PushSDK.getInstance(getApplicationContext()).registerPushListener(
					pushListener);
		}
	}

	private Observer pushListener = new Observer() {

		@Override
		public void update(Observable observable, Object data) {
			if (data instanceof String) {
				String ret = (String) data;
				// Date date = new Date(System.currentTimeMillis());
				// SimpleDateFormat format = new
				// SimpleDateFormat("yy-MM-dd HH:mm:ss");
				if (!"+h".equals(ret.trim())) {
					// 不是心跳消息时，广播次消息出去
					try {
						JSONObject object = new JSONObject(ret.trim());
						Intent intent = new Intent();
						// 设置应用程序包名
						intent.setPackage(object.optString("pname"));
						/* 设置Intent对象的action属性 */
						intent.setAction(PushConstants.ACTION_MESSAGE);
						/* 为Intent对象添加附加信息 */
						intent.putExtra(PushConstants.EXTRA_PUSH_MESSAGE_STRING, object.optJSONObject("msg").toString());
						/* 发布广播 */
						sendBroadcast(intent);
					} catch (JSONException e) {
						e.printStackTrace();
					}
				} else {
					// BLog.v("--" + getApplication().getPackageName()+
					// "-->>>> " + ret + ",time："
					// + format.format(date));
				}
			}
		}
	};

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// 关了推送后再开记得改回来
		isUnReceive = false;
		if (Build.VERSION.SDK_INT < 18) {
			startForeground();
		} else {
			intent = new Intent(this, PushNotifyService.class);
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
				startForegroundService(intent);
			} else {
				startService(intent);
			}
			startForeground();
		}
		// 每隔一分钟发一次time，去检测service有没有被杀死，如果杀死了就重启
		if (!isUnReceive) {
			// registerBroadcast();
			sendKeepBroadcast();
			// 不管push服务有没有启动起来，都需要注册观察者
			PushSDK.getInstance(getApplicationContext()).registerPushListener(pushListener);
			// 在你需要回调的地方，注册回调
			handleCommand(intent);
		}
		return START_STICKY;
	}
	private final static int IM_SERVICE_ID = 1001;

	private void startForeground() {
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
			String id="ID";
			String name="NAME";
			NotificationChannel channel = new NotificationChannel(id, name, NotificationManager.IMPORTANCE_LOW);
			NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
			manager.createNotificationChannel(channel);
			Notification notification = new Notification.Builder(this, id).build();
			startForeground(IM_SERVICE_ID, notification);
		}else {
			startForeground(IM_SERVICE_ID, new Notification());
		}
	}

	/**
	 * 用AlarmManager周期发广播，让Service一直在运行
	 */
	private void sendKeepBroadcast() {
		// 获取闹钟服务对象
		mAlarmManager = (AlarmManager) getApplicationContext().getSystemService(Context.ALARM_SERVICE);
		Intent intent = new Intent(getApplicationContext(), PushNotifyReceiver.class);
		intent.setAction(PushConstants.ACTION_NOTIFY);
		getApplicationContext().sendBroadcast(intent);
		mPendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 0,intent, 0);
		// 当前时间每隔60秒执行一次
		mAlarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
				System.currentTimeMillis(), 60 * 1000, mPendingIntent);
	}

	/**
	 * 取消用AlarmManager周期发的广播，
	 */
	private void cancleKeepBroadcast() {
		mAlarmManager.cancel(mPendingIntent);
	}

	private void handleCommand(Intent intent) {
		if (null == intent) {
			BLog.d("PushService", "handleCommand() pid:"
					+ (android.os.Process.myPid()) + " tid:"
					+ (android.os.Process.myTid()));
		}
		BLog.d("PushService", "handleCommand()");
		if (NetworkUtil.isNetworkAvailable(getApplicationContext())) {// 网络可用
			if (!isUnReceive) {
				mClient.open(mSocketResponseListener);
			}
		}
	}

	@Override
	public IBinder onBind(Intent arg0) {
		BLog.d("PushService", "PushService-->onBind()");
		if (PushService.class.getName().equals(arg0.getAction())) {
			handleCommand(arg0);
			return mBinder;
		}
		return null;
	}

	@Override
	public boolean onUnbind(Intent intent) {
		BLog.d("PushService", "PushService-->onUnbind()");
		mClient.close();
		return super.onUnbind(intent);
	}

	@Override
	public void onDestroy() {
		BLog.d("PushService", "PushService-->onDestroy()");
		mClient.close();
		mCallbacks.kill();
		android.os.Process.killProcess(android.os.Process.myPid());
		super.onDestroy();
	}

	/**
	 * 在Client类中的onTextMessage方法中收到消息会通知 socket数据回调
	 */
	private ISocketResponse mSocketResponseListener = new ISocketResponse() {

		@Override
		public void onSocketResponse(int code, Object retObject) {
			Bundle mBundle = new Bundle();
			mBundle.putByteArray("data", (byte[]) retObject);
			final int callbacksNum = mCallbacks.beginBroadcast();
			for (int i = callbacksNum - 1; i >= 0; i--) {
				try {
					mCallbacks.getBroadcastItem(i).response(mBundle);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mCallbacks.finishBroadcast();
		}
	};

	private final CusRemoteCallbackList<ISocketServiceCallback> mCallbacks = new CusRemoteCallbackList<ISocketServiceCallback>();
	private ISocketService.Stub mBinder = new ISocketService.Stub() {

		@Override
		public int request(Bundle mBundle) throws RemoteException {
			byte[] data = mBundle.getByteArray("data");
			if (null != data) {
				return mClient.send(new ClientPacket(data));
			}
			return 0;
		}

		@Override
		public void registerCallback(Bundle mBundle, ISocketServiceCallback cb)
				throws RemoteException {
			if (cb != null) {
				boolean isRegistered = mCallbacks.register(cb);
				BLog.d("PushService", "registerCallback isRegistered："+ isRegistered);
			}
		}

		@Override
		public void unregisterCallback(Bundle mBundle, ISocketServiceCallback cb)
				throws RemoteException {
			if (cb != null) {
				boolean isUnregistered = mCallbacks.unregister(cb);
				BLog.i("PushService registerCallback isUnregistered"+ isUnregistered);
				setUnReceive(isUnregistered);
				// 取消AM发的心跳广播
				mClient.cancleHeartBeat();
				// 取消AM发的检测Service是否运行的广播
				cancleKeepBroadcast();
				mClient.close();
			}
		}

	};

	/**
	 * 经过测试onCallbackDied()方法，只有在bindService()，没有调用unbind()方法process就挂了的情况下才会执行
	 */
	private class CusRemoteCallbackList<E extends IInterface> extends
			RemoteCallbackList<E> {
		@Override
		public void onCallbackDied(E callback) {
			super.onCallbackDied(callback);

		}

		@Override
		public void onCallbackDied(E callback, Object cookie) {
			super.onCallbackDied(callback, cookie);
		}
	}

}
